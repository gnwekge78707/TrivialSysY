package frontend.symbol;

public interface Symbol {
    String getName();
}

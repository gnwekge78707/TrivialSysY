package frontend.syntax.stmt.ast;

public interface Stmt {
    void checkErrors();
}
